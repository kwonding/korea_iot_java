package org.example.test0710.자바OOP구현문제;

abstract class Shape {
    abstract double getArea ();
}

class Circle extends Shape {
    @Override
    double getArea() {
        return 0;
    }
}

class Rectangle extends Shape {
    @Override
    double getArea() {
        return 0;
    }
}

public class Q3 {
    public static void main(String[] args) {

    }
}
