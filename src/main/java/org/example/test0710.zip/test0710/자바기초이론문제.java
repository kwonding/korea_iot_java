package org.example.test0710;

public class 자바기초이론문제 {
}
/*
Q1. D
Q2. A
Q3.
Q4. B
Q5. B
Q6. C
Q7. C
Q8. C
Q9. D
Q10. D
Q11. 2
Q12. @Override 하지않아서

 */